import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { ResumeService, AnalysisResult } from '../services/resume.service';
import { Router } from '@angular/router';
import { DatePipe, UpperCasePipe, CommonModule } from '@angular/common';

// External library declaration
declare var jspdf: any;

@Component({
  selector: 'app-download',
  standalone: true,
  imports: [DatePipe, UpperCasePipe, CommonModule],
  template: `
    <div class="max-w-[1100px] mx-auto px-4 md:px-6 py-10 md:py-20 animate-fade-in relative z-10">
      
      @if (!sanitizedResult()) {
        <div class="text-center py-20">
          <p class="mb-6 text-[#B8B8B8] font-light">No report available to export.</p>
          <button (click)="goHome()" class="text-sm border-b border-[#EAEAEA] pb-1 hover:text-[#C2B8A3] hover:border-[#C2B8A3] transition-colors">Return Home</button>
        </div>
      } @else {

        <!-- UI Section -->
        <div class="text-center space-y-8 mb-16">
          <h2 class="text-2xl md:text-3xl font-medium uppercase tracking-widest text-[#EAEAEA]">Report Ready</h2>
          <div class="space-y-2 px-4">
            <p class="text-[#B8B8B8] text-xs md:text-sm max-w-lg mx-auto font-light">
              Your structured analysis is complete. The document will be generated as a standardized, vector-based PDF.
            </p>
          </div>
          
          <div class="px-4 w-full flex justify-center">
            <button (click)="generatePdf()" 
                    [disabled]="isDownloading()"
                    class="w-full sm:w-auto border border-[#EAEAEA] px-10 py-4 md:py-5 text-sm font-bold uppercase tracking-[0.2em] 
                           bg-transparent text-[#EAEAEA] 
                           hover:bg-[#EAEAEA] hover:text-black hover:border-[#C2B8A3]
                           disabled:opacity-50 disabled:cursor-wait
                           transition-all duration-300">
               @if (isDownloading()) {
                 GENERATING PDF...
               } @else {
                 DOWNLOAD PDF FILE
               }
            </button>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .animate-fade-in {
      animation: fadeIn 1s ease-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
  `]
})
export class DownloadComponent implements OnInit {
  resumeService = inject(ResumeService);
  router = inject(Router);
  
  // Data State
  sanitizedResult = computed(() => {
    const raw = this.resumeService.analysisResult();
    return raw ? this.deepSanitize(raw) : null;
  });

  date = new Date();
  isDownloading = signal<boolean>(false);

  ngOnInit() {
    if (!this.sanitizedResult()) {
      this.router.navigate(['/']);
    }
  }

  // --- PDF GENERATION LOGIC ---

  async generatePdf() {
    const data = this.sanitizedResult();
    if (!data) return;

    this.isDownloading.set(true);

    // Short delay to allow UI to update
    await new Promise(resolve => setTimeout(resolve, 50));

    try {
      const { jsPDF } = jspdf;
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      // CONSTANTS
      const PAGE_HEIGHT = 297;
      const MARGIN_TOP = 20;
      const MARGIN_LEFT = 20;
      const MARGIN_RIGHT = 20;
      const CONTENT_WIDTH = 210 - MARGIN_LEFT - MARGIN_RIGHT; // 170mm
      
      let cursorY = MARGIN_TOP;

      // FONTS
      // 'Courier' is standard in PDF, looks like typewriter
      doc.setFont('Courier', 'normal');

      // --- HELPER: ADD TEXT WITH AUTO-PAGING ---
      const addText = (text: string, fontSize: number, isBold: boolean = false, align: 'left' | 'center' | 'right' = 'left', indent: number = 0) => {
        doc.setFont('Courier', isBold ? 'bold' : 'normal');
        doc.setFontSize(fontSize);
        
        const lines = doc.splitTextToSize(text, CONTENT_WIDTH - indent);
        const lineHeight = fontSize * 0.3527 * 1.5; // pt to mm conversion + line height factor

        for (let i = 0; i < lines.length; i++) {
          if (cursorY + lineHeight > PAGE_HEIGHT - 20) {
            doc.addPage();
            cursorY = MARGIN_TOP;
          }
          
          let xPos = MARGIN_LEFT + indent;
          if (align === 'center') xPos = 105; // Center of A4
          if (align === 'right') xPos = 210 - MARGIN_RIGHT;

          doc.text(lines[i], xPos, cursorY, { align: align });
          cursorY += lineHeight;
        }
        cursorY += 2; // Paragraph spacing
      };

      const addDivider = () => {
        if (cursorY + 5 > PAGE_HEIGHT - 20) {
            doc.addPage();
            cursorY = MARGIN_TOP;
        }
        doc.setLineWidth(0.1);
        doc.line(MARGIN_LEFT, cursorY, 210 - MARGIN_RIGHT, cursorY);
        cursorY += 8;
      };

      const addSectionTitle = (title: string) => {
         cursorY += 4;
         if (cursorY + 10 > PAGE_HEIGHT - 20) {
            doc.addPage();
            cursorY = MARGIN_TOP;
         }
         doc.setFont('Courier', 'bold');
         doc.setFontSize(11);
         doc.text(title.toUpperCase(), MARGIN_LEFT, cursorY);
         
         // Underline
         const textWidth = doc.getTextWidth(title.toUpperCase());
         doc.setLineWidth(0.1);
         doc.line(MARGIN_LEFT, cursorY + 1, MARGIN_LEFT + textWidth, cursorY + 1);
         
         cursorY += 8;
      };

      // --- RENDER CONTENT ---

      // 1. HEADER
      doc.setFont('Courier', 'bold');
      doc.setFontSize(16);
      doc.text("RESUME ANALYSIS", MARGIN_LEFT, cursorY);
      
      // Score (Right Aligned)
      doc.setFontSize(30);
      doc.text(`${data.score}/100`, 210 - MARGIN_RIGHT, cursorY + 2, { align: 'right' });
      
      cursorY += 8;
      
      doc.setFont('Courier', 'normal');
      doc.setFontSize(9);
      doc.text(`ROLE: ${this.resumeService.selectedRole().toUpperCase()}`, MARGIN_LEFT, cursorY);
      
      doc.setFontSize(8);
      doc.text("MATCH SCORE", 210 - MARGIN_RIGHT, cursorY, { align: 'right' });
      
      cursorY += 5;
      doc.setFontSize(9);
      doc.text(`DATE: ${this.date.toLocaleDateString().toUpperCase()}`, MARGIN_LEFT, cursorY);
      
      cursorY += 10;
      addDivider();

      // 2. OVERVIEW
      addSectionTitle('01. Executive Summary');
      addText(data.overview, 10);
      cursorY += 4;

      // 3. STRENGTHS
      addSectionTitle('02. Key Strengths');
      data.strengths.forEach((str: string) => {
        addText(`• ${str}`, 10, false, 'left', 5);
      });
      cursorY += 4;

      // 4. SKILLS
      addSectionTitle('03. Skill Breakdown');
      if (data.skills.languages?.length) {
        addText('LANGUAGES:', 9, true);
        addText(data.skills.languages.join(', '), 10);
      }
      if (data.skills.frameworks?.length) {
        addText('FRAMEWORKS:', 9, true);
        addText(data.skills.frameworks.join(', '), 10);
      }
      if (data.skills.databases?.length) {
        addText('DATABASES:', 9, true);
        addText(data.skills.databases.join(', '), 10);
      }
      if (data.skills.other?.length) {
        addText('OTHER:', 9, true);
        addText(data.skills.other.join(', '), 10);
      }
      cursorY += 4;

      // 5. MISSING
      if (data.missing?.length) {
        addSectionTitle('04. Missing Sections');
        data.missing.forEach((m: any) => {
           addText(`[MISSING] ${m.name.toUpperCase()}`, 10, true, 'left', 0);
           addText(m.importance, 10, false, 'left', 0);
           cursorY += 2;
        });
        cursorY += 4;
      }

      // 6. IMPROVEMENTS
      addSectionTitle('05. Strategic Improvements');
      data.improvements.forEach((imp: any) => {
        addText(`REC: ${imp.recommendation}`, 10, true, 'left', 0);
        addText(`WHY: ${imp.reason}`, 10, false, 'left', 5);
        addText(`ACT: ${imp.action}`, 10, false, 'left', 5);
        cursorY += 4;
      });
      
      // 7. ROLE ALIGNMENT
      addSectionTitle('06. Role Alignment');
      addText(`FIT LEVEL: ${data.roleAlignment.matchLevel}`, 10, true);
      cursorY += 2;
      
      if (data.roleAlignment.gaps?.length) {
        addText('GAPS:', 9, true);
        data.roleAlignment.gaps.forEach((g: string) => addText(`- ${g}`, 10, false, 'left', 5));
      }
      if (data.roleAlignment.suggestions?.length) {
        cursorY += 2;
        addText('SUGGESTIONS:', 9, true);
        data.roleAlignment.suggestions.forEach((s: string) => addText(`+ ${s}`, 10, false, 'left', 5));
      }
      cursorY += 6;

      // 8. ACTION PLAN
      addSectionTitle('07. Priority Action Plan');
      data.actionPlan.forEach((step: string, index: number) => {
        addText(`${index + 1}. ${step}`, 10, false, 'left', 5);
      });

      // FOOTER
      const totalPages = doc.internal.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setFont('Courier', 'normal');
        doc.text('Generated by AI Resume Analyzer', 105, 290, { align: 'center' });
      }

      // SAVE
      doc.save(`Resume_Analysis_${this.resumeService.selectedRole().replace(/\s+/g, '_')}.pdf`);

    } catch (err) {
      console.error('PDF Generation Error:', err);
      alert('Failed to generate PDF. Please try again.');
    } finally {
      this.isDownloading.set(false);
    }
  }

  goHome() {
    this.router.navigate(['/']);
  }

  // Sanitization
  private deepSanitize(obj: any): any {
    if (typeof obj === 'string') {
      return this.sanitizeText(obj);
    } else if (Array.isArray(obj)) {
      return obj.map(item => this.deepSanitize(item));
    } else if (typeof obj === 'object' && obj !== null) {
      const newObj: any = {};
      for (const key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          newObj[key] = this.deepSanitize(obj[key]);
        }
      }
      return newObj;
    }
    return obj;
  }

  private sanitizeText(text: string): string {
    if (!text) return '';
    return text
      .replace(/[\u200B-\u200D\uFEFF]/g, '')
      .replace(/\u00A0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }
}