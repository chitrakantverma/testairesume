import { Component, inject } from '@angular/core';
import { ResumeService } from '../services/resume.service';
import { Router } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-upload',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <div class="max-w-[1100px] mx-auto px-4 md:px-6 py-10 md:py-20 animate-fade-in w-full min-h-[70vh] flex items-center justify-center">
      <div class="w-full max-w-2xl">
        
        <div class="mb-8 md:mb-12 text-center">
           <h2 class="text-2xl md:text-3xl font-medium uppercase tracking-widest mb-3 md:mb-4 text-[#EAEAEA]">Input Parameters</h2>
           <p class="text-[#B8B8B8] text-xs md:text-sm font-light">Upload your document and define the analysis context.</p>
        </div>

        <form [formGroup]="uploadForm" (ngSubmit)="onSubmit()" class="space-y-8 md:space-y-12">
          
          <!-- Role Selection -->
          <div class="space-y-3 md:space-y-4">
            <label for="role" class="block text-xs font-normal uppercase tracking-widest text-[#B8B8B8]">Target Role</label>
            <div class="relative group">
              <select id="role" formControlName="role" 
                      class="w-full appearance-none bg-transparent border border-[#333] text-[#EAEAEA] px-4 md:px-6 py-3 md:py-4 rounded-none 
                             text-sm font-light focus:outline-none focus:border-[#C2B8A3] focus:ring-0 transition-colors cursor-pointer">
                <option value="" disabled selected class="bg-black text-[#555]">SELECT TARGET ROLE</option>
                <option value="Software Developer" class="bg-black text-[#EAEAEA]">Software Developer</option>
                <option value="Web Developer" class="bg-black text-[#EAEAEA]">Web Developer</option>
                <option value="Data Analyst" class="bg-black text-[#EAEAEA]">Data Analyst</option>
                <option value="Fresher / Student" class="bg-black text-[#EAEAEA]">Fresher / Student</option>
              </select>
              <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 md:px-6 text-[#EAEAEA] group-hover:text-[#C2B8A3]">
                <span class="text-[10px]">▼</span>
              </div>
            </div>
          </div>

          <!-- File Upload -->
          <div class="space-y-3 md:space-y-4">
            <div class="flex justify-between items-end flex-wrap gap-2">
                <label for="resume" class="block text-xs font-normal uppercase tracking-widest text-[#B8B8B8]">
                    Upload Resume
                </label>
                <span class="text-[10px] text-[#555] uppercase tracking-wide">PDF, PNG, JPG</span>
            </div>
            
            <div class="relative border border-[#333] hover:border-[#555] transition-colors p-1 focus-within:border-[#C2B8A3]">
              <input type="file" id="resume" (change)="onFileSelected($event)" accept="application/pdf, image/png, image/jpeg, image/jpg"
                   class="block w-full text-xs md:text-sm text-[#B8B8B8]
                          file:mr-4 md:file:mr-6 file:py-3 md:file:py-4 file:px-4 md:file:px-8
                          file:border-0 file:border-r file:border-[#333]
                          file:text-[10px] md:file:text-xs file:font-normal file:uppercase file:tracking-widest
                          file:bg-[#111] file:text-[#EAEAEA]
                          hover:file:bg-[#EAEAEA] hover:file:text-black
                          file:transition-colors cursor-pointer" />
            </div>
            <p class="text-[10px] mt-2 text-[#555] uppercase tracking-wide text-right">
                Vision Analysis enabled for images
            </p>
          </div>

          @if (resumeService.error()) {
            <div class="border border-red-900/50 p-4 md:p-6 bg-transparent text-red-300 text-xs font-mono break-words">
              ERROR: {{ resumeService.error() }}
            </div>
          }

          <!-- Submit Button -->
          <div class="pt-4 md:pt-8">
            <button type="submit" 
                    [disabled]="uploadForm.invalid || !selectedFile || resumeService.isLoading()"
                    class="w-full border border-[#EAEAEA] px-8 py-4 md:py-5 text-sm font-bold uppercase tracking-[0.2em] 
                           bg-transparent text-[#EAEAEA] 
                           hover:bg-[#EAEAEA] hover:text-black hover:border-[#C2B8A3]
                           disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-[#EAEAEA] disabled:hover:border-[#333]
                           transition-all duration-300">
              @if (resumeService.isLoading()) {
                <span class="animate-pulse">{{ resumeService.statusMessage() }}</span>
              } @else {
                <span>Initialize Analysis</span>
              }
            </button>
          </div>

        </form>
      </div>
    </div>
  `,
  styles: [`
    .animate-fade-in {
      animation: fadeIn 0.8s ease-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
  `]
})
export class UploadComponent {
  resumeService = inject(ResumeService);
  router = inject(Router);
  private fb: FormBuilder = inject(FormBuilder);

  selectedFile: File | null = null;
  uploadForm = this.fb.group({
    role: ['', Validators.required]
  });

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
    }
  }

  async onSubmit() {
    if (this.uploadForm.valid && this.selectedFile) {
      await this.resumeService.analyzeResume(this.selectedFile, this.uploadForm.value.role!);
      if (!this.resumeService.error()) {
        this.router.navigate(['/results']);
      }
    }
  }
}