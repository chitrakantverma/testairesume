import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink],
  template: `
    <!-- Mobile-First Container: min-height instead of fixed height for scroll safety on small screens -->
    <div class="relative w-full min-h-[calc(100vh-80px)] flex items-center justify-center overflow-hidden py-12 md:py-0">
      
      <!-- System Pulse: Scanning Vertical Line (Background Layer) -->
      <div class="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div class="h-full w-[1px] bg-white/10 animate-scan blur-[1px]"></div>
      </div>

      <!-- Content -->
      <div class="relative z-10 w-full max-w-4xl mx-auto px-4 md:px-6 text-center space-y-10 md:space-y-12">
        
        <!-- Hero Text Group -->
        <div class="space-y-6 md:space-y-8">
          <!-- Title: Scaled Typography -->
          <h1 class="text-3xl sm:text-4xl md:text-6xl font-medium tracking-tight uppercase leading-tight opacity-0 animate-enter-up text-[#EAEAEA]" 
              style="animation-delay: 0.2s;">
            AI Resume<br>Analyzer
          </h1>
          
          <!-- Subtitle -->
          <div class="space-y-3 opacity-0 animate-enter-up px-2" style="animation-delay: 0.6s;">
            <p class="text-sm md:text-base text-[#B8B8B8] font-light tracking-[0.05em] max-w-xl mx-auto leading-relaxed">
              An AI-assisted system for resume analysis, clarity, and improvement.
            </p>
            <p class="text-xs text-[#B8B8B8] font-light opacity-60">
              Focused on clarity, structure, and role relevance.
            </p>
          </div>
        </div>

        <!-- Terminal Feature List -->
        <div class="flex flex-col items-center gap-2 md:gap-3 text-[10px] md:text-sm font-mono text-[#B8B8B8] h-12 md:h-16 justify-center">
           <div class="typing-line opacity-0 animate-type-reveal" style="animation-delay: 1.2s;">> Completeness Analysis initialized...</div>
           <div class="typing-line opacity-0 animate-type-reveal" style="animation-delay: 1.8s;">> Role-Specific Feedback Model ready.</div>
        </div>

        <!-- CTA Button: Full width on mobile, auto on desktop -->
        <div class="pt-4 md:pt-6 opacity-0 animate-fade-in w-full flex justify-center px-4 md:px-0" style="animation-delay: 2.4s;">
          <a routerLink="/upload" 
             class="cta-button block w-full sm:w-auto border border-[#EAEAEA] px-10 py-4 text-xs font-bold uppercase tracking-[0.2em] 
                    bg-transparent text-[#EAEAEA] transition-all duration-300 hover:bg-[#EAEAEA] hover:text-black hover:border-[#C2B8A3] text-center">
            Analyze Your Resume
          </a>
        </div>
        
        <!-- System Status Box: Stacked on very small screens -->
        <div class="pt-12 md:pt-16 opacity-0 animate-fade-in" style="animation-delay: 3.0s;">
          <div class="inline-flex flex-col items-center gap-2 border-t border-[#333] pt-6 px-4 md:px-16 w-full md:w-auto">
             <div class="flex flex-col sm:flex-row gap-4 sm:gap-8 text-[10px] font-mono tracking-widest uppercase items-center">
               <div class="flex items-center gap-2">
                 <span class="text-[#B8B8B8]">Status:</span>
                 <span class="text-[#C2B8A3] flex items-center gap-2">
                   <span class="block w-1.5 h-1.5 bg-[#C2B8A3] rounded-sm animate-pulse-status"></span>
                   Ready
                 </span>
               </div>
               <div class="flex items-center gap-2">
                  <span class="text-[#B8B8B8]">Model:</span>
                  <span class="text-[#C2B8A3]">Gemini 2.5 Flash</span>
               </div>
             </div>
          </div>
        </div>

      </div>

      <!-- Scroll Cue: Hide on very short mobile screens -->
      <div class="absolute bottom-4 md:bottom-6 left-1/2 -translate-x-1/2 text-center opacity-0 animate-fade-in hidden md:block" style="animation-delay: 3.5s; animation-fill-mode: forwards;">
         <div class="animate-pulse-slow">
            <p class="text-[10px] uppercase tracking-widest text-[#B8B8B8] mb-2 opacity-60">Scroll to explore</p>
            <div class="h-6 w-[1px] bg-[#C2B8A3] mx-auto opacity-40"></div>
         </div>
      </div>
    </div>
  `,
  styles: [`
    /* Animations remain same */
    @keyframes enterUp {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    @keyframes typeReveal {
      from { opacity: 0; transform: translateX(-5px); }
      to { opacity: 1; transform: translateX(0); }
    }
    @keyframes scan {
      0% { transform: translateX(-10vw); opacity: 0; }
      15% { opacity: 0.5; }
      85% { opacity: 0.5; }
      100% { transform: translateX(110vw); opacity: 0; }
    }
    @keyframes pulseSlow {
      0%, 100% { opacity: 0.3; }
      50% { opacity: 1; }
    }
    @keyframes pulseStatus {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.4; }
    }

    .animate-enter-up { animation: enterUp 1s cubic-bezier(0.2, 1, 0.3, 1) forwards; }
    .animate-fade-in { animation: fadeIn 1.2s ease-out forwards; }
    .animate-type-reveal { animation: typeReveal 0.5s ease-out forwards; }
    .animate-scan { animation: scan 15s linear infinite; }
    .animate-pulse-slow { animation: pulseSlow 4s ease-in-out infinite; }
    .animate-pulse-status { animation: pulseStatus 2s steps(2) infinite; }
  `]
})
export class HomeComponent {}