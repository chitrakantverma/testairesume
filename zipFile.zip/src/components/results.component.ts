import { Component, inject, OnInit } from '@angular/core';
import { ResumeService } from '../services/resume.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-results',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="max-w-[1100px] mx-auto px-4 md:px-6 py-8 md:py-12 pb-24 md:pb-32">
      
      @if (!result()) {
        <div class="text-center py-20 md:py-32 animate-fade-in">
          <p class="mb-6 text-[#B8B8B8] font-light">No analysis data currently available.</p>
          <button (click)="goBack()" class="border border-[#333] px-6 py-2 text-xs uppercase text-[#B8B8B8] hover:border-[#C2B8A3] hover:text-[#EAEAEA] transition-all">Return to Upload</button>
        </div>
      } @else {
        
        <!-- Header Section: Stacked on mobile, Row on desktop -->
        <header class="mb-10 md:mb-16 border-b border-[#333] pb-6 md:pb-8 animate-slide-up" style="animation-delay: 0.1s;">
          <div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 md:gap-0">
            <div>
              <p class="text-[10px] uppercase tracking-widest text-[#B8B8B8] mb-2">Target Role</p>
              <h1 class="text-2xl md:text-5xl font-medium text-[#EAEAEA] uppercase tracking-wide break-words">{{ resumeService.selectedRole() }}</h1>
            </div>
            <div class="text-left md:text-right w-full md:w-auto flex items-center md:block gap-4 md:gap-0">
              <span class="block text-5xl md:text-6xl font-bold text-[#EAEAEA]">{{ result()?.score }}</span>
              <span class="text-[10px] uppercase tracking-[0.2em] text-[#C2B8A3] block pt-1 md:pt-0">Match Score</span>
            </div>
          </div>
        </header>

        <!-- 1. Overview -->
        <section class="mb-12 md:mb-20 animate-slide-up" style="animation-delay: 0.2s;">
          <div class="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8">
            <div class="md:col-span-3">
              <h3 class="text-xs font-normal uppercase tracking-widest text-[#B8B8B8]">01. Profile Overview</h3>
            </div>
            <div class="md:col-span-9">
              <p class="text-base md:text-lg leading-relaxed font-light text-[#EAEAEA] border-l-2 border-[#C2B8A3] pl-4 md:pl-6">
                {{ result()?.overview }}
              </p>
            </div>
          </div>
        </section>

        <!-- 2. Strengths -->
        <section class="mb-12 md:mb-20 animate-slide-up" style="animation-delay: 0.3s;">
          <div class="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8">
            <div class="md:col-span-3">
              <h3 class="text-xs font-normal uppercase tracking-widest text-[#B8B8B8]">02. Key Strengths</h3>
            </div>
            <div class="md:col-span-9">
              <ul class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3 md:gap-y-4">
                @for (strength of result()?.strengths; track strength) {
                  <li class="flex items-start">
                    <span class="text-[#C2B8A3] mr-3 mt-1.5 text-[10px]">●</span>
                    <span class="text-sm font-light text-[#EAEAEA]">{{ strength }}</span>
                  </li>
                }
              </ul>
            </div>
          </div>
        </section>

        <!-- 3. Skills Breakdown -->
        <section class="mb-12 md:mb-20 animate-slide-up" style="animation-delay: 0.4s;">
          <div class="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8">
            <div class="md:col-span-3">
              <h3 class="text-xs font-normal uppercase tracking-widest text-[#B8B8B8]">03. Skill Matrix</h3>
            </div>
            <div class="md:col-span-9">
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-8">
                
                @if (result()?.skills?.languages?.length) {
                  <div>
                    <h4 class="text-[10px] uppercase text-[#555] mb-3 tracking-widest">Languages</h4>
                    <div class="flex flex-wrap gap-2">
                      @for (item of result()?.skills?.languages; track item) {
                        <span class="border border-[#333] px-3 py-1 text-xs text-[#EAEAEA]">{{ item }}</span>
                      }
                    </div>
                  </div>
                }

                @if (result()?.skills?.frameworks?.length) {
                  <div>
                    <h4 class="text-[10px] uppercase text-[#555] mb-3 tracking-widest">Frameworks & Tools</h4>
                    <div class="flex flex-wrap gap-2">
                      @for (item of result()?.skills?.frameworks; track item) {
                        <span class="border border-[#333] px-3 py-1 text-xs text-[#EAEAEA]">{{ item }}</span>
                      }
                    </div>
                  </div>
                }

                @if (result()?.skills?.databases?.length) {
                  <div>
                    <h4 class="text-[10px] uppercase text-[#555] mb-3 tracking-widest">Databases</h4>
                    <div class="flex flex-wrap gap-2">
                      @for (item of result()?.skills?.databases; track item) {
                        <span class="border border-[#333] px-3 py-1 text-xs text-[#EAEAEA]">{{ item }}</span>
                      }
                    </div>
                  </div>
                }

                @if (result()?.skills?.other?.length) {
                  <div>
                    <h4 class="text-[10px] uppercase text-[#555] mb-3 tracking-widest">Other Technical</h4>
                    <div class="flex flex-wrap gap-2">
                      @for (item of result()?.skills?.other; track item) {
                        <span class="border border-[#333] px-3 py-1 text-xs text-[#EAEAEA]">{{ item }}</span>
                      }
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>
        </section>

        <!-- 4. Missing Sections -->
        @if (result()?.missing?.length) {
          <section class="mb-12 md:mb-20 animate-slide-up" style="animation-delay: 0.5s;">
            <div class="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8">
              <div class="md:col-span-3">
                <h3 class="text-xs font-normal uppercase tracking-widest text-[#B8B8B8]">04. Critical Missing Gaps</h3>
              </div>
              <div class="md:col-span-9">
                <div class="space-y-4 md:space-y-6">
                  @for (miss of result()?.missing; track miss.name) {
                    <div class="flex items-start gap-4">
                      <div class="min-w-[4px] h-[4px] bg-[#EAEAEA] mt-2 rounded-full"></div>
                      <div>
                         <p class="text-sm font-bold text-[#EAEAEA] mb-1 uppercase tracking-wider">Missing: {{ miss.name }}</p>
                         <p class="text-sm font-light text-[#B8B8B8]">{{ miss.importance }}</p>
                      </div>
                    </div>
                  }
                </div>
              </div>
            </div>
          </section>
        }

        <!-- 5. Improvements -->
        <section class="mb-12 md:mb-20 animate-slide-up" style="animation-delay: 0.6s;">
          <div class="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8">
            <div class="md:col-span-3">
              <h3 class="text-xs font-normal uppercase tracking-widest text-[#B8B8B8]">05. Strategic Improvements</h3>
            </div>
            <div class="md:col-span-9">
              <div class="space-y-6 md:space-y-8">
                @for (imp of result()?.improvements; track imp.recommendation; let i = $index) {
                  <div class="border border-[#333] p-4 md:p-6 hover:border-[#555] transition-colors group">
                    <div class="flex items-baseline gap-4 mb-4">
                      <span class="text-lg font-bold text-[#333] group-hover:text-[#C2B8A3] transition-colors">0{{ i + 1 }}</span>
                      <h4 class="text-sm md:text-base font-medium text-[#EAEAEA]">{{ imp.recommendation }}</h4>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <span class="text-[10px] uppercase text-[#555] block mb-2 tracking-widest">Why it matters</span>
                        <p class="text-xs md:text-sm text-[#B8B8B8] font-light">{{ imp.reason }}</p>
                      </div>
                      <div>
                         <span class="text-[10px] uppercase text-[#555] block mb-2 tracking-widest">Actionable Step</span>
                         <p class="text-xs md:text-sm text-[#EAEAEA] font-light">{{ imp.action }}</p>
                      </div>
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>
        </section>

        <!-- 6. Role Alignment -->
        <section class="mb-12 md:mb-20 animate-slide-up" style="animation-delay: 0.7s;">
          <div class="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8">
            <div class="md:col-span-3">
               <h3 class="text-xs font-normal uppercase tracking-widest text-[#B8B8B8]">06. Role Alignment</h3>
            </div>
            <div class="md:col-span-9">
               <div class="flex items-center gap-4 mb-6">
                 <span class="text-sm text-[#B8B8B8] uppercase tracking-widest">Fit Level:</span>
                 <span class="px-3 py-1 bg-[#EAEAEA] text-black text-xs font-bold uppercase tracking-widest">{{ result()?.roleAlignment?.matchLevel }}</span>
               </div>
               
               <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                 <div>
                   <h5 class="text-xs text-[#C2B8A3] uppercase mb-3 tracking-wide">Identified Gaps</h5>
                   <ul class="space-y-2">
                     @for (gap of result()?.roleAlignment?.gaps; track gap) {
                       <li class="text-sm text-[#B8B8B8] font-light flex gap-2">
                         <span>-</span> {{ gap }}
                       </li>
                     }
                   </ul>
                 </div>
                 <div>
                   <h5 class="text-xs text-[#EAEAEA] uppercase mb-3 tracking-wide">Suggested Additions</h5>
                   <ul class="space-y-2">
                     @for (sug of result()?.roleAlignment?.suggestions; track sug) {
                       <li class="text-sm text-[#B8B8B8] font-light flex gap-2">
                         <span>+</span> {{ sug }}
                       </li>
                     }
                   </ul>
                 </div>
               </div>
            </div>
          </div>
        </section>

        <!-- 7. Action Plan -->
        <section class="mb-12 md:mb-20 animate-slide-up" style="animation-delay: 0.8s;">
          <div class="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8">
             <div class="md:col-span-3">
               <h3 class="text-xs font-normal uppercase tracking-widest text-[#B8B8B8]">07. Priority Action Plan</h3>
             </div>
             <div class="md:col-span-9">
                <div class="space-y-4">
                  @for (step of result()?.actionPlan; track step; let i = $index) {
                     <div class="flex items-start gap-4">
                        <div class="min-w-[24px] h-[24px] border border-[#C2B8A3] rounded-full flex items-center justify-center text-[10px] text-[#C2B8A3] mt-0.5">
                          {{ i + 1 }}
                        </div>
                        <p class="text-sm md:text-base text-[#EAEAEA] font-light">{{ step }}</p>
                     </div>
                  }
                </div>
             </div>
          </div>
        </section>
        
        <!-- Actions -->
        <div class="flex justify-end pt-8 border-t border-[#333] animate-slide-up" style="animation-delay: 0.9s;">
           <button (click)="goToDownload()" class="w-full md:w-auto border border-[#EAEAEA] px-10 py-5 text-sm font-bold uppercase tracking-[0.2em] 
                           bg-transparent text-[#EAEAEA] 
                           hover:bg-[#EAEAEA] hover:text-black hover:border-[#C2B8A3]
                           transition-all duration-300">
             Proceed to Download
           </button>
        </div>

      }
    </div>
  `,
  styles: [`
    /* Staggered Animation */
    @keyframes slideUpFade {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .animate-slide-up {
      opacity: 0;
      animation: slideUpFade 0.8s cubic-bezier(0.2, 1, 0.3, 1) forwards;
    }

    .animate-fade-in {
      animation: fadeIn 1s ease-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
  `]
})
export class ResultsComponent implements OnInit {
  resumeService = inject(ResumeService);
  router = inject(Router);
  
  result = this.resumeService.analysisResult;

  ngOnInit() {
    if (!this.result()) {
      this.router.navigate(['/upload']);
    }
  }

  goBack() {
    this.router.navigate(['/upload']);
  }

  goToDownload() {
    this.router.navigate(['/download']);
  }
}