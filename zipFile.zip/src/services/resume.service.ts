import { Injectable, signal } from '@angular/core';
import { GoogleGenAI, Type } from '@google/genai';

// 3. Skill Breakdown Structure
export interface SkillCategory {
  languages: string[];
  frameworks: string[];
  databases: string[];
  other: string[];
}

// 4. Missing Section Structure
export interface MissingSection {
  name: string;
  importance: string;
}

// 5. Improvement Structure
export interface Improvement {
  recommendation: string; // What
  reason: string;         // Why
  action: string;         // How
}

// 6. Role Alignment Structure
export interface RoleAlignment {
  matchLevel: string; // Low, Medium, High
  gaps: string[];
  suggestions: string[];
}

// Main Analysis Result
export interface AnalysisResult {
  score: number;
  overview: string;                  // 1. Overview
  strengths: string[];               // 2. Key Strengths
  skills: SkillCategory;             // 3. Skills
  missing: MissingSection[];         // 4. Missing Sections
  improvements: Improvement[];       // 5. Improvements
  roleAlignment: RoleAlignment;      // 6. Role Alignment
  actionPlan: string[];              // 7. Action Plan
}

@Injectable({
  providedIn: 'root'
})
export class ResumeService {
  
  // State
  isLoading = signal<boolean>(false);
  statusMessage = signal<string>('');
  analysisResult = signal<AnalysisResult | null>(null);
  selectedRole = signal<string>('');
  error = signal<string | null>(null);

  constructor() {}

  async analyzeResume(file: File, role: string) {
    const apiKey = process.env['API_KEY'];
    if (!apiKey) {
      this.error.set('API Configuration Error: Missing API Key.');
      return;
    }

    const mimeType = file.type;
    const isImage = mimeType.startsWith('image/');
    const isPdf = mimeType === 'application/pdf';

    if (!isImage && !isPdf) {
      this.error.set('Unsupported file type. Please upload a PDF or Image (PNG/JPG).');
      return;
    }

    this.isLoading.set(true);
    this.statusMessage.set('Initializing secure upload...');
    this.error.set(null);
    this.selectedRole.set(role);
    this.analysisResult.set(null); // Clear previous result

    try {
      let base64Data: string;

      if (isImage) {
        this.statusMessage.set('Optimizing scan for visual analysis...');
        base64Data = await this.compressImage(file);
      } else {
        this.statusMessage.set('Reading document structure...');
        base64Data = await this.readFileAsBase64(file);
      }

      this.statusMessage.set('Processing content with Gemini 2.5 Flash...');
      const ai = new GoogleGenAI({ apiKey: apiKey });

      const prompt = `
        Act as a strict, senior-level technical recruiter and academic resume evaluator.
        Analyze this resume (provided as ${isImage ? 'an image' : 'a PDF document'}) specifically for the role of "${role}".
        
        ${isImage ? 'Perform OCR to extract all visible text before analyzing.' : ''}

        Produce a structured critique following these exact sections:
        
        1. OVERVIEW: 3-4 sentences summarizing the candidate's profile, years of experience, and primary domain.
        2. STRENGTHS: Specific bullet points referencing skills, experience, or achievements.
        3. SKILLS: Categorized into Languages, Frameworks, Databases, and Other.
        4. MISSING: Explicitly list missing or weak sections (e.g., Projects, Metrics) and explain why they matter.
        5. IMPROVEMENTS: Actionable advice. For each point, specify WHAT to improve, WHY it matters, and HOW to do it.
        6. ALIGNMENT: Analyze fit for "${role}". State match level (Low/Medium/High), gaps, and suggestions.
        7. PLAN: A prioritized list of 3-5 next steps.

        Be critical and professional. Avoid generic praise.
      `;

      this.statusMessage.set('Evaluating role alignment & skills...');
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
          role: 'user',
          parts: [
            { inlineData: { mimeType: isImage ? 'image/jpeg' : mimeType, data: base64Data } },
            { text: prompt }
          ]
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.NUMBER, description: "Overall score out of 100" },
              overview: { type: Type.STRING, description: "3-4 sentence summary" },
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              skills: { 
                type: Type.OBJECT,
                properties: {
                  languages: { type: Type.ARRAY, items: { type: Type.STRING } },
                  frameworks: { type: Type.ARRAY, items: { type: Type.STRING } },
                  databases: { type: Type.ARRAY, items: { type: Type.STRING } },
                  other: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
              },
              missing: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    importance: { type: Type.STRING }
                  }
                }
              },
              improvements: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    recommendation: { type: Type.STRING, description: "What to improve" },
                    reason: { type: Type.STRING, description: "Why it matters" },
                    action: { type: Type.STRING, description: "How to improve it" }
                  }
                }
              },
              roleAlignment: {
                type: Type.OBJECT,
                properties: {
                  matchLevel: { type: Type.STRING, description: "Low, Medium, or High" },
                  gaps: { type: Type.ARRAY, items: { type: Type.STRING } },
                  suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
              },
              actionPlan: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ['score', 'overview', 'strengths', 'skills', 'missing', 'improvements', 'roleAlignment', 'actionPlan']
          }
        }
      });

      this.statusMessage.set('Formatting structured report...');
      
      const text = response.text;
      if (text) {
        const json = JSON.parse(text);
        this.analysisResult.set(json as AnalysisResult);
      } else {
        throw new Error('No analysis generated.');
      }

    } catch (e: any) {
      console.error(e);
      this.error.set(e.message || 'An unexpected error occurred during analysis.');
    } finally {
      this.isLoading.set(false);
      this.statusMessage.set('');
    }
  }

  private readFileAsBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        const base64String = result.split(',')[1];
        resolve(base64String);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  private compressImage(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.src = url;
      
      img.onload = () => {
        URL.revokeObjectURL(url);
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) { reject(new Error('Canvas error')); return; }
        
        const maxDim = 1500;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > maxDim) { height *= maxDim / width; width = maxDim; }
        } else {
          if (height > maxDim) { width *= maxDim / height; height = maxDim; }
        }
        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.8).split(',')[1]);
      };
      img.onerror = (e) => {
        URL.revokeObjectURL(url);
        reject(e);
      };
    });
  }
}