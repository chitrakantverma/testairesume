import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <div class="min-h-screen flex flex-col w-full bg-black text-[#EAEAEA] relative overflow-x-hidden selection:bg-[#C2B8A3] selection:text-black">
      
      <!-- PART 1: SYSTEM-LEVEL BACKGROUND ANIMATION -->
      <!-- Adjusted opacity for mobile to reduce visual noise -->
      <div class="fixed inset-0 z-0 pointer-events-none overflow-hidden print-hide">
        <div class="absolute inset-0 bg-system-grid opacity-[0.05] md:opacity-[0.08] animate-grid-flow"></div>
      </div>

      <!-- Header / Sticky Nav -->
      <!-- Mobile-First: Auto height, stacked layout on small screens -->
      <header class="sticky top-0 z-50 bg-black/95 backdrop-blur-sm border-b border-[#333] print-hide transition-all duration-500">
        <div class="max-w-[1100px] mx-auto px-4 md:px-6 py-4 md:h-20 flex flex-col md:flex-row justify-between items-center gap-4 md:gap-0">
          
          <!-- Logo -->
          <div class="text-xs md:text-sm font-medium tracking-[0.15em] uppercase text-[#EAEAEA] hover:text-white transition-colors cursor-default select-none text-center md:text-left">
            AI Resume Analyzer
          </div>

          <!-- Navigation -->
          <nav class="flex flex-wrap justify-center md:justify-end gap-x-6 gap-y-2 text-[10px] md:text-xs tracking-widest font-normal">
            <a routerLink="/" 
               routerLinkActive="active" 
               [routerLinkActiveOptions]="{exact: true}"
               class="nav-link relative py-2 text-[#B8B8B8] hover:text-[#EAEAEA] transition-colors duration-300">
               HOME
               <span class="underline-indicator"></span>
            </a>
            <a routerLink="/upload" 
               routerLinkActive="active"
               class="nav-link relative py-2 text-[#B8B8B8] hover:text-[#EAEAEA] transition-colors duration-300">
               UPLOAD
               <span class="underline-indicator"></span>
            </a>
            <a routerLink="/results" 
               routerLinkActive="active"
               class="nav-link relative py-2 text-[#B8B8B8] hover:text-[#EAEAEA] transition-colors duration-300">
               RESULTS
               <span class="underline-indicator"></span>
            </a>
            <a routerLink="/download" 
               routerLinkActive="active"
               class="nav-link relative py-2 text-[#B8B8B8] hover:text-[#EAEAEA] transition-colors duration-300">
               DOWNLOAD
               <span class="underline-indicator"></span>
            </a>
          </nav>
        </div>
      </header>

      <!-- Main Content -->
      <main class="flex-grow w-full relative z-10">
        <router-outlet></router-outlet>
      </main>

      <!-- Footer -->
      <footer class="py-8 md:py-12 border-t border-[#333] text-center print-hide relative z-10 px-4">
        <div class="max-w-[1100px] mx-auto">
          <p class="text-[10px] text-[#B8B8B8] font-light tracking-widest uppercase opacity-60 leading-relaxed">
            This system provides AI-assisted suggestions. Final decisions remain with the user.
          </p>
        </div>
      </footer>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
    
    /* Background Pattern */
    .bg-system-grid {
      /* Creates a 40px x 40px grid of 1px dots */
      background-image: radial-gradient(circle, #EAEAEA 1px, transparent 1px);
      background-size: 40px 40px;
    }

    /* Continuous Background Motion */
    @keyframes gridFlow {
      0% { transform: translateY(0); }
      100% { transform: translateY(40px); }
    }
    .animate-grid-flow {
      animation: gridFlow 20s linear infinite;
    }
    
    /* Navigation Underline Animation */
    .underline-indicator {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 1px;
      background-color: #C2B8A3; /* Accent Color */
      transform: scaleX(0);
      transform-origin: center;
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .nav-link:hover .underline-indicator,
    .nav-link.active .underline-indicator {
      transform: scaleX(1);
    }

    .nav-link.active {
      color: #EAEAEA;
    }
  `]
})
export class AppComponent {}